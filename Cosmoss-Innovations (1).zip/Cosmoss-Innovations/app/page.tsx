import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Brain, Cpu, Shield, BotIcon as Robot } from 'lucide-react'

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <section className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-4">Welcome to Flamepath Academy</h1>
        <p className="text-xl text-gray-600 mb-8">Your Guide to Mastering the Future of Technology</p>
        <div className="flex justify-center space-x-4">
          <Button asChild>
            <Link href="/learning-hub">Explore Learning Hub</Link>
          </Button>
          <Button asChild variant="outline" className="dark:text-white">
            <Link href="/resources">Browse Resources</Link>
          </Button>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
        {[
          { title: 'AI', icon: Brain },
          { title: 'Machine Learning', icon: Cpu },
          { title: 'Robotics', icon: Robot },
          { title: 'Cybersecurity', icon: Shield }
        ].map((topic) => (
          <Link key={topic.title} href={`/category/${topic.title.toLowerCase().replace(' ', '-')}`}>
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <topic.icon className="mr-2" />
                  {topic.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Explore our latest {topic.title} resources and get expert assistance.</CardDescription>
              </CardContent>
            </Card>
          </Link>
        ))}
      </section>

      <section className="bg-gray-100 p-8 rounded-lg mb-16">
        <h2 className="text-2xl font-bold mb-4">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {['Interactive Chat', 'Smart Search', 'Personalized Learning'].map((feature) => (
            <Card key={feature} className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <CardTitle>{feature}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Experience advanced technology with our {feature.toLowerCase()} feature.</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to Begin Your Journey?</h2>
        <p className="text-xl mb-8">Start Learning Today</p>
        <Button asChild size="lg" className="bg-primary text-white dark:bg-white dark:text-black">
          <Link href="/signup">Get Started Now</Link>
        </Button>
      </section>
    </div>
  )
}

